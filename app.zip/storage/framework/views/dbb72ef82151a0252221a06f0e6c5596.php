<!DOCTYPE html>
<html>

<head>
    <title>My app</title>
</head>
<script src="index.js"></script>

<body>
    <p>This paragraph is a part of HTML.</p>
    <nav id="navigation"></nav>
    <p>This paragraph is also a part of HTML.</p>
</body>

</html><?php /**PATH D:\laragon\www\Start\resources\views/index.blade.php ENDPATH**/ ?>